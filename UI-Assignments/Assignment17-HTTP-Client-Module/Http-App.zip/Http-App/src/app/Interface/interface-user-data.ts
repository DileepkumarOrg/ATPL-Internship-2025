export interface InterfaceUserData {
    id:number,
    name : string,
    email : string
}
